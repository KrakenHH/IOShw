homework 4 for ios class


Notes to self:

Make sure to set identifier for table view cells

Connect table view cell in storyboard to the appropriate table view cell class

Connect the table view controller in the storyboard to the table view controller class